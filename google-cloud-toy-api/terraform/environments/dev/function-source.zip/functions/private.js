"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.privateMessage = void 0;
const privateMessage = (req, res) => {
    res.status(200).send({ message: 'Hello from the private endpoint!' });
};
exports.privateMessage = privateMessage;
