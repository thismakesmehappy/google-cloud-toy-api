"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.publicMessage = void 0;
const publicMessage = (req, res) => {
    res.status(200).send({ message: 'Hello from the public endpoint!' });
};
exports.publicMessage = publicMessage;
