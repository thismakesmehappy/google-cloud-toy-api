"use strict";
// This file can be used to define custom types for your application.
// For example:
// export interface User {
//   uid: string;
//   email: string;
//   displayName: string;
// }
